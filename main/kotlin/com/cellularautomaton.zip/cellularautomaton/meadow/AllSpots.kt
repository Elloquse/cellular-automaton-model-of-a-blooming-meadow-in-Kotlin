package com.cellularautomaton.meadow

import com.cellularautomaton.bee.AllHives
import com.cellularautomaton.plant.AllFlowers

class AllSpots (meadowSizeX: Int, meadowSizeY: Int){

    init {
        for (line in 1..meadowSizeY) {
            for (column in 1..meadowSizeX) {
                spotsMap[listOf(line, column)] = Spot(column, line)
            }
        }
    }

    companion object {
        val spotsMap: MutableMap<List<Int?>, Spot> = mutableMapOf()

        fun getSpotObject(x: Int?, y: Int?): Spot? {
            return spotsMap[listOf(x, y)]
        }
    }

    fun addHives(hives: List<List<Int?>>) {
        hives.forEach {
            spotsMap[it]?.spotOccupancy = AllHives.placeHive(spotsMap[it])
        }
    }

    fun addFlowers(flowers: Map<List<Int?>, String?>) {
        flowers.forEach { (key, value) ->
            spotsMap[key]?.spotSeedsOn?.add(AllFlowers.placeFlower(spotsMap[key], value))
        }
    }

    fun showSpots() {
        for (i in spotsMap) {
            println("${i.key} : ${i.value.spotOccupancy}")
        }
    }
}