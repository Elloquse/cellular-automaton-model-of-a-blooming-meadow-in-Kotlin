package com.cellularautomaton.meadow

import com.cellularautomaton.plant.Flower

class Spot (private val x: Int, private val y: Int) {

    var spotOccupancy: Any? = null
    var spotSeedsOn: MutableList<Flower> = mutableListOf()
    var spotBeesOn: Any? = null

    fun willSeedGerminate(flowerType: Flower): Boolean? {
        val probOfGerm: Double = (spotSeedsOn.count {
            it::class.simpleName == flowerType::class.simpleName
        } / spotSeedsOn.size.toDouble())

        return probOfGerm > (1.0 - probOfGerm) && spotOccupancy == null
    }

    fun getPosition(): String {
        return "x=$x y=$y"
    }

    fun getXCoordinate(): Int {
        return x
    }

    fun getYCoordinate(): Int {
        return y
    }
}