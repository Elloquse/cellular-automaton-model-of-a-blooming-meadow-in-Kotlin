package com.cellularautomaton

interface Tick {
    fun tick()
}