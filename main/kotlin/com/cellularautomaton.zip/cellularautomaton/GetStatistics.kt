package com.cellularautomaton

interface GetStatistics {

    fun getStatistics() {}

}