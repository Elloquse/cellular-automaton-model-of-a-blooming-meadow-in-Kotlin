package com.cellularautomaton.plant

import com.cellularautomaton.Tick
import com.cellularautomaton.meadow.AllSpots
import com.cellularautomaton.meadow.Spot

abstract class Flower : Tick {

    var plantSpot: Spot? = null
    abstract var plantState: Any?
    private var plantAge: Int = 0
    private var plantNectar: Int = 0
    private var isPollinated: Boolean = false

    open fun germinate() {
        plantSpot?.spotOccupancy = plantSpot
        PlantState.changeState(this, "SEEDLING")
    }

    private fun growAdult() {
        PlantState.changeState(this, "ADULT")
    }

    private fun bloom() {
        PlantState.changeState(this, "BLOOMING")
    }

    private fun produceNectar() {
        plantNectar += (1..5).random()
    }

    private fun fruit() {
        PlantState.changeState(this, "FRUITION")
    }

    private fun die() {
        plantSpot?.spotOccupancy = null
        PlantState.changeState(this, "DIED")
        AllFlowers.removeFlower(this)
    }


    private fun produceSeed() {
        val x = plantSpot?.getXCoordinate()
        val y = plantSpot?.getYCoordinate()
        for (cell in 1..(1..3).random()) {
            if (x != null && y != null) {
                val spotToSeedOn: Spot? = AllSpots.getSpotObject((x-1..x+1).random(), (y-1..y+1).random())
                if (spotToSeedOn != null) {
                    AllFlowers.placeFlower(spotToSeedOn, this::class.simpleName)
                }
            }
        }
    }

    fun giveAwayNectar(): Int {
        val nectar: Int = plantNectar
        plantNectar = 0
        return nectar
    }

    override fun tick() {
        when (this.plantState.toString()) {
            "SEED" -> {
                if (plantAge > PlantState.getLifeTime(this)) {
                    val germinateOrNot: Boolean? = plantSpot?.willSeedGerminate(this)
                    if (germinateOrNot == true) {
                        plantAge = 1
                        germinate()
                    } else {
                        die()
                    }
                } else {
                    plantAge += 1

                }
            }
            "SEEDLING" -> {
                if (plantAge > PlantState.getLifeTime(this)) {
                    plantAge = 1
                    growAdult()
                } else {
                    produceSeed()
                    plantAge += 1
                }
            }
            "ADULT" -> {
                if (plantAge > PlantState.getLifeTime(this)) {
                    plantAge = 1
                    bloom()
                } else {
                    plantAge += 1
                }
            }
            "BLOOMING" -> {
                if (plantAge > PlantState.getLifeTime(this) && isPollinated) {
                    plantAge = 1
                    fruit()
                } else if (plantAge > PlantState.getLifeTime(this) && !isPollinated) {
                    die()
                } else {
                    plantAge += 1
                    produceNectar()
                }
            }
            "FRUITION" -> {
                val fruitionTime = (1..PlantState.getLifeTime(this)).random()
                if (plantAge > PlantState.getLifeTime(this)) {
                    die()
                } else if (plantAge == fruitionTime) {
                    produceSeed()
                    plantAge += 1
                } else {
                    plantAge += 1
                }
            }
        }
    }
}