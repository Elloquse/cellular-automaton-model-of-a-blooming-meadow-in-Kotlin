package com.cellularautomaton.plant

class Chamomile : Flower() {

    override var plantState: Any? = PlantState.ChamomileState.valueOf("SEED")


}