package com.cellularautomaton.plant

class PlantState() {

    companion object {
        fun changeState(flower: Flower, toWhichState: String): Any {
            return when (flower) {
                is Chamomile -> flower.plantState = PlantState.ChamomileState.valueOf(toWhichState.uppercase())
                is Dandelion -> flower.plantState = PlantState.DandelionState.valueOf(toWhichState.uppercase())
                else -> throw Exception("No such plant state")
            }
        }

        fun getLifeTime(flower: Flower): Int {
            return when (flower) {
                is Chamomile -> PlantState.ChamomileState.valueOf(flower.plantState.toString()).lifetime
                is Dandelion -> PlantState.DandelionState.valueOf(flower.plantState.toString()).lifetime
                else -> throw Exception("No such plant state")
            }
        }
    }

    enum class ChamomileState(val lifetime: Int) {
        SEED(2),
        SEEDLING (3),
        ADULT(7),
        BLOOMING(3),
        FRUITION(2),
        DIED(0)
    }

    enum class DandelionState(val lifetime: Int) {
        SEED(2),
        SEEDLING(4),
        ADULT(5),
        BLOOMING(2),
        FRUITION(3),
        DIED(0)
    }
}