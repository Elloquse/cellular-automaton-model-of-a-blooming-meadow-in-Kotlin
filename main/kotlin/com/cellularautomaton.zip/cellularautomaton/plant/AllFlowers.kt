package com.cellularautomaton.plant

import com.cellularautomaton.GetStatistics
import com.cellularautomaton.Tick
import com.cellularautomaton.meadow.Spot

object AllFlowers : GetStatistics {

    private val flowersList: MutableList<Flower> = mutableListOf()

    fun placeFlower(spot: Spot?, flower: String?): Flower {
        val newFlower: Flower = when (flower) {
            "Chamomile" -> Chamomile()
            "Dandelion" -> Dandelion()
            else -> throw Exception("Unidentified flowers, check your initial values")
        }

        newFlower.plantSpot = spot
        newFlower.plantSpot?.spotSeedsOn?.add(newFlower)
        if (!flowersList.contains(newFlower)) {
            flowersList.add(newFlower)
        }
        return newFlower
    }

    fun tick() {
        for (flower in flowersList.toList()) {
            flower.tick()
        }
    }

    fun removeFlower(flower: Flower) {
        flowersList.remove(flower)
    }

    override fun getStatistics() {
        println("-----Plants statistics-----")
        println("Total flowers: ${flowersList.filter { it.plantState.toString() != "SEED" }.size}")
        println("Number of Dandelions: ${flowersList.filter { it::class.simpleName == "Dandelion" && it.plantState.toString() != "SEED"}.size}")
        println("Number of Chamomiles: ${flowersList.filter { it::class.simpleName == "Chamomile" && it.plantState.toString() != "SEED"}.size}")
//        println("List of all flowers:")
//        flowersList.forEach {flower ->
//            println("${flower::class.simpleName} -- cell position ${flower.plantSpot?.getPosition()} -- stage ${flower.plantState}")
//        }
        println("---------------------------")
        println()
    }
}