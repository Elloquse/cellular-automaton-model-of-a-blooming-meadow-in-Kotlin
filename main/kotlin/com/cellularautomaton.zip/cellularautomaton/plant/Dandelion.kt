package com.cellularautomaton.plant

class Dandelion : Flower() {

   override var plantState: Any? = PlantState.DandelionState.valueOf("SEED")

}