package com.cellularautomaton.bee

class Bee {
    val nectarLoadCapacity: Int = 5
    val maxFlights: Int = 3
    val maxFlightsRange: Int = 10

    fun move() {

    }

    fun die() {

    }
}