package com.cellularautomaton.bee

import com.cellularautomaton.Tick
import com.cellularautomaton.meadow.Spot

object AllHives {

    private val hivesList: MutableList<Hive> = mutableListOf<Hive>()

    fun placeHive(spot: Spot?): Hive {
        val newHive = Hive()
        newHive.hiveSpot = spot
        hivesList.add(newHive)
        return newHive
    }

}