package com.cellularautomaton.bee

import com.cellularautomaton.meadow.Spot

class Hive() {
    var hiveSpot: Spot? = null

    private var beesAlive: Int = (10..100).random()
    private var beesList: MutableList<Bee> = mutableListOf()
    private var beesDead: Int = 0
    private var beesGeneration: Int = 1

    private var nectarCurrent: Int = 0
    private var nectarTotal: Int = 0
    private var nectarSpent: Int = 0

    private val newGenerationTime: Int = 2
    private val maxBeesCapacity: Int = 100

    init {
        for (bee in 1..beesAlive) {
            beesList.add(Bee())
        }
    }

    fun createNewGeneration() {
        println(beesList.size)
    }

    fun getBees(): MutableList<Bee> {
        return beesList
    }
}